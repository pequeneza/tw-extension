import express from 'express';
import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT         = process.env.PORT       ?? 3741;
const ADMIN_USER   = process.env.ADMIN_USER ?? 'admin';
const ADMIN_PASS   = process.env.ADMIN_PASS;

if (!ADMIN_PASS) {
  console.error('Error: set ADMIN_PASS environment variable before starting.');
  process.exit(1);
}

// ── Database ──────────────────────────────────────────────────────────────────

const db = new Database(join(__dirname, 'licenses.db'));
db.exec(`
  CREATE TABLE IF NOT EXISTS licenses (
    key        TEXT PRIMARY KEY,
    name       TEXT    DEFAULT '',
    note       TEXT    DEFAULT '',
    created_at TEXT    DEFAULT (datetime('now')),
    active     INTEGER DEFAULT 1
  )
`);

const q = {
  list:    db.prepare('SELECT * FROM licenses ORDER BY created_at DESC'),
  get:     db.prepare('SELECT active FROM licenses WHERE key = ?'),
  insert:  db.prepare('INSERT INTO licenses (key, name, note) VALUES (?, ?, ?)'),
  setActive: db.prepare('UPDATE licenses SET active = ? WHERE key = ?'),
  delete:  db.prepare('DELETE FROM licenses WHERE key = ?'),
  stats:   db.prepare('SELECT SUM(active) AS active, SUM(1 - active) AS revoked FROM licenses'),
};

function generateKey() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const seg = () => Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `${seg()}-${seg()}-${seg()}-${seg()}`;
}

// ── Middleware ─────────────────────────────────────────────────────────────────

const app = express();
app.use(express.json());
app.use(express.static(join(__dirname, 'public')));

function requireAuth(req, res, next) {
  const header = req.headers.authorization ?? '';
  if (!header.startsWith('Basic ')) {
    res.set('WWW-Authenticate', 'Basic realm="xBot Admin"');
    return res.status(401).send('Unauthorized');
  }
  const [user, pass] = Buffer.from(header.slice(6), 'base64').toString().split(':');
  if (user !== ADMIN_USER || pass !== ADMIN_PASS) {
    return res.status(403).send('Forbidden');
  }
  next();
}

// ── Public route (extension) ───────────────────────────────────────────────────

app.post('/validate', (req, res) => {
  const { key } = req.body ?? {};
  if (!key || typeof key !== 'string') return res.json({ valid: false });
  const row = q.get.get(key.trim().toUpperCase());
  res.json({ valid: row?.active === 1 });
});

// ── Admin routes (web UI) ──────────────────────────────────────────────────────

app.get('/admin/stats', requireAuth, (_req, res) => {
  res.json(q.stats.get());
});

app.get('/admin/keys', requireAuth, (_req, res) => {
  res.json(q.list.all());
});

app.post('/admin/keys', requireAuth, (req, res) => {
  const { name = '', note = '' } = req.body ?? {};
  const key = generateKey();
  q.insert.run(key, name.trim(), note.trim());
  res.json({ key });
});

app.patch('/admin/keys/:key', requireAuth, (req, res) => {
  const { active } = req.body ?? {};
  q.setActive.run(active ? 1 : 0, req.params.key);
  res.json({ ok: true });
});

app.delete('/admin/keys/:key', requireAuth, (req, res) => {
  q.delete.run(req.params.key);
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`xBot license server → http://localhost:${PORT}`));
